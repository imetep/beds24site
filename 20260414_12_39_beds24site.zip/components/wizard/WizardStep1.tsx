'use client';
import { useEffect, useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { useWizardStore } from '@/store/wizard-store';
import { getAvailableRooms, getPropertyForRoom, PROPERTIES } from '@/config/properties';
import type { Room } from '@/config/properties';

// ─── Offer IDs fissi LivingApple ─────────────────────────────────────────────
const OFFER_NAMES: Record<number, Record<string, string>> = {
  1: { it:'Non Rimborsabile',          en:'Non-Refundable',         de:'Nicht erstattungsfähig',    pl:'Bezzwrotna' },
  2: { it:'Parzialmente Rimborsabile', en:'Partially Refundable',   de:'Teilw. erstattungsfähig',   pl:'Częściowo zwrotna' },
  3: { it:'Flessibile 60 gg',          en:'Flexible 60 days',       de:'Flexibel 60 Tage',          pl:'Elastyczna 60 dni' },
  4: { it:'Flessibile 45 gg',          en:'Flexible 45 days',       de:'Flexibel 45 Tage',          pl:'Elastyczna 45 dni' },
  5: { it:'Flessibile 30 gg',          en:'Flexible 30 days',       de:'Flexibel 30 Tage',          pl:'Elastyczna 30 dni' },
  6: { it:'Flessibile 5 gg',           en:'Flexible 5 days',        de:'Flexibel 5 Tage',           pl:'Elastyczna 5 dni' },
};
const OFFER_DESC: Record<number, Record<string, string>> = {
  1: { it:'Paghi tutto entro 48h dalla prenotazione.',       en:'Pay in full within 48h of booking.',                de:'Vollzahlung innerhalb 48h nach Buchung.',          pl:'Płatność w całości w ciągu 48h.' },
  2: { it:"Paghi 50% ora, il saldo all'arrivo.",             en:'Pay 50% now, balance at arrival.',                  de:'50% jetzt, Rest bei Ankunft.',                     pl:'50% teraz, reszta przy przyjeździe.' },
  3: { it:"Cancellazione gratuita entro 60 gg dall'arrivo.", en:'Free cancellation up to 60 days before arrival.',   de:'Kostenlose Stornierung bis 60 Tage vor Ankunft.',  pl:'Bezpłatne anulowanie do 60 dni przed przyjazdem.' },
  4: { it:"Cancellazione gratuita entro 45 gg dall'arrivo.", en:'Free cancellation up to 45 days before arrival.',   de:'Kostenlose Stornierung bis 45 Tage vor Ankunft.',  pl:'Bezpłatne anulowanie do 45 dni przed przyjazdem.' },
  5: { it:"Cancellazione gratuita entro 30 gg dall'arrivo.", en:'Free cancellation up to 30 days before arrival.',   de:'Kostenlose Stornierung bis 30 Tage vor Ankunft.',  pl:'Bezpłatne anulowanie do 30 dni przed przyjazdem.' },
  6: { it:"Cancellazione gratuita entro 5 gg dall'arrivo.",  en:'Free cancellation up to 5 days before arrival.',    de:'Kostenlose Stornierung bis 5 Tage vor Ankunft.',   pl:'Bezpłatne anulowanie do 5 dni przed przyjazdem.' },
};

// ─── Traduzioni UI ────────────────────────────────────────────────────────────
const UI: Record<string, Record<string, string>> = {
  it: {
    titleSingle:'Quale tariffa preferite?',
    titleMulti: 'Scegli appartamento e tariffa',
    loading: 'Ricerca prezzi e disponibilità...',
    noResults: 'Nessun appartamento disponibile per le date selezionate.',
    nightsSing: 'notte', nightsPlur: 'notti',
    perNight: '/notte', total: 'totale',
    continua: 'Continua →', indietro: '← Indietro',
    errTitle: 'Errore caricamento prezzi', retry: 'Riprova',
    camere: 'camere', maxPers: 'max', persone: 'pers.',
    privPool: '🏊 Piscina privata', sharedPool: '🌊 Piscina condivisa', noPool: '🏖️ 250m dal mare',
    nearSea: 'Vicino al mare', nature: 'Immerso nella natura',
    nonDisp: 'Non disponibile', selezionata: '✓',
    // Filtri
    filterAll:        'Tutti',
    filterPriceLow:   'Prezzo ↑',
    filterPriceHigh:  'Prezzo ↓',
    filterSize:       'Più grande',
    filterSea:        '250m mare',
    filterNature:     '2km mare',
    // Desktop dropdown labels
    filterAllLong:        'Predefinito',
    filterPriceLowLong:   'Prezzo più basso',
    filterPriceHighLong:  'Prezzo più alto',
    filterSizeLong:       'Più grande (mq)',
    filterSeaLong:        '250m dal mare',
    filterNatureLong:     '2km dal mare',
    filterAllClean: 'Tutti', filterPriceClean: 'Prezzo', filterSizeClean: 'Più grande', filterSeaClean: '250m dal mare', filterNatureClean: '2km dal mare',
    poolAll: 'Piscina: tutte', poolPrivate: '🏊 Privata', poolShared: '🌊 Condivisa',
    typeAll: 'Tipo: tutti', typeMono: 'Monolocale', typeAppart: 'Appartamento', typeVilla: 'Villa',
    filtriBtn: 'Filtri', filtriTitle: 'Ordina e filtra', filtriApply: 'Applica', filtriClear: 'Cancella tutto',
    sortSection: 'Ordina per', seaSection: 'Distanza dal mare', poolSection: 'Piscina', typeSection: 'Tipo di casa', bedsSection: 'Camere da letto',
    sortDefault: 'Predefinito', sortPriceLow: 'Prezzo crescente', sortPriceHigh: 'Prezzo decrescente', sortBiggest: 'Più grande', sortSmallest: 'Più piccolo',
    seaAll: 'Tutte le strutture', sea250: '250m dal mare', sea2km: 'Immerso nella natura',
    bedsAny: 'Qualsiasi',
  },
  en: {
    titleSingle:'Which rate do you prefer?',
    titleMulti: 'Choose apartment and rate',
    loading: 'Searching prices and availability...',
    noResults: 'No apartments available for the selected dates.',
    nightsSing: 'night', nightsPlur: 'nights',
    perNight: '/night', total: 'total',
    continua: 'Continue →', indietro: '← Back',
    errTitle: 'Error loading prices', retry: 'Retry',
    camere: 'bd', maxPers: 'max', persone: 'pax',
    privPool: '🏊 Private pool', sharedPool: '🌊 Shared pool', noPool: '🏖️ 250m from sea',
    nearSea: 'Near the sea', nature: 'In nature',
    nonDisp: 'Unavailable', selezionata: '✓',
    filterAll:        'All',
    filterPriceLow:   'Price ↑',
    filterPriceHigh:  'Price ↓',
    filterSize:       'Largest',
    filterSea:        '250m sea',
    filterNature:     '2km sea',
    filterAllLong:        'Default',
    filterPriceLowLong:   'Lowest price',
    filterPriceHighLong:  'Highest price',
    filterSizeLong:       'Largest (sqm)',
    filterSeaLong:        '250m from sea',
    filterNatureLong:     '2km from sea',
    filterAllClean: 'All', filterPriceClean: 'Price', filterSizeClean: 'Largest', filterSeaClean: '250m from sea', filterNatureClean: '2km from sea',
    poolAll: 'Pool: all', poolPrivate: '🏊 Private', poolShared: '🌊 Shared',
    typeAll: 'Type: all', typeMono: 'Studio', typeAppart: 'Apartment', typeVilla: 'Villa',
    filtriBtn: 'Filters', filtriTitle: 'Sort and filter', filtriApply: 'Apply', filtriClear: 'Clear all',
    sortSection: 'Sort by', seaSection: 'Distance from sea', poolSection: 'Pool', typeSection: 'Property type', bedsSection: 'Bedrooms',
    sortDefault: 'Default', sortPriceLow: 'Price: low to high', sortPriceHigh: 'Price: high to low', sortBiggest: 'Largest', sortSmallest: 'Smallest',
    seaAll: 'All properties', sea250: '250m from sea', sea2km: 'In nature',
    bedsAny: 'Any',
  },
  de: {
    titleSingle:'Welchen Tarif bevorzugen Sie?',
    titleMulti: 'Unterkunft und Tarif wählen',
    loading: 'Preise und Verfügbarkeit suchen...',
    noResults: 'Keine Unterkünfte für die gewählten Daten verfügbar.',
    nightsSing: 'Nacht', nightsPlur: 'Nächte',
    perNight: '/Nacht', total: 'gesamt',
    continua: 'Weiter →', indietro: '← Zurück',
    errTitle: 'Fehler beim Laden', retry: 'Wiederholen',
    camere: 'Zi.', maxPers: 'max', persone: 'Pers.',
    privPool: '🏊 Privater Pool', sharedPool: '🌊 Gemeinsch.pool', noPool: '🏖️ 250m vom Meer',
    nearSea: 'Meeresnähe', nature: 'In der Natur',
    nonDisp: 'Nicht verfügbar', selezionata: '✓',
    filterAll:        'Alle',
    filterPriceLow:   'Preis ↑',
    filterPriceHigh:  'Preis ↓',
    filterSize:       'Größte',
    filterSea:        '250m Meer',
    filterNature:     '2km Meer',
    filterAllLong:        'Standard',
    filterPriceLowLong:   'Günstigster Preis',
    filterPriceHighLong:  'Höchster Preis',
    filterSizeLong:       'Größte (qm)',
    filterSeaLong:        '250m vom Meer',
    filterNatureLong:     '2km vom Meer',
    filterAllClean: 'Alle', filterPriceClean: 'Preis', filterSizeClean: 'Größte', filterSeaClean: '250m vom Meer', filterNatureClean: '2km vom Meer',
    poolAll: 'Pool: alle', poolPrivate: '🏊 Privat', poolShared: '🌊 Geteilt',
    typeAll: 'Typ: alle', typeMono: 'Studio', typeAppart: 'Appartement', typeVilla: 'Villa',
    filtriBtn: 'Filter', filtriTitle: 'Sortieren & filtern', filtriApply: 'Anwenden', filtriClear: 'Alles löschen',
    sortSection: 'Sortieren nach', seaSection: 'Meeresentfernung', poolSection: 'Pool', typeSection: 'Unterkunftstyp', bedsSection: 'Schlafzimmer',
    sortDefault: 'Standard', sortPriceLow: 'Preis aufsteigend', sortPriceHigh: 'Preis absteigend', sortBiggest: 'Größte', sortSmallest: 'Kleinste',
    seaAll: 'Alle Unterkünfte', sea250: '250m vom Meer', sea2km: 'In der Natur',
    bedsAny: 'Beliebig',
  },
  pl: {
    titleSingle:'Którą taryfę preferujecie?',
    titleMulti: 'Wybierz apartament i taryfę',
    loading: 'Wyszukiwanie cen i dostępności...',
    noResults: 'Brak dostępnych apartamentów dla wybranych dat.',
    nightsSing: 'noc', nightsPlur: 'nocy',
    perNight: '/noc', total: 'łącznie',
    continua: 'Dalej →', indietro: '← Wstecz',
    errTitle: 'Błąd ładowania cen', retry: 'Ponów',
    camere: 'sypialnie', maxPers: 'maks', persone: 'os.',
    privPool: '🏊 Prywatny basen', sharedPool: '🌊 Wspólny basen', noPool: '🏖️ 250m od morza',
    nearSea: 'Blisko morza', nature: 'Wśród natury',
    nonDisp: 'Niedostępne', selezionata: '✓',
    filterAll:        'Wszystkie',
    filterPriceLow:   'Cena ↑',
    filterPriceHigh:  'Cena ↓',
    filterSize:       'Największy',
    filterSea:        '250m morze',
    filterNature:     '2km morze',
    filterAllLong:        'Domyślne',
    filterPriceLowLong:   'Najniższa cena',
    filterPriceHighLong:  'Najwyższa cena',
    filterSizeLong:       'Największy (mkw)',
    filterSeaLong:        '250m od morza',
    filterNatureLong:     '2km od morza',
    filterAllClean: 'Wszystkie', filterPriceClean: 'Cena', filterSizeClean: 'Największy', filterSeaClean: '250m od morza', filterNatureClean: '2km od morza',
    poolAll: 'Basen: wszystkie', poolPrivate: '🏊 Prywatny', poolShared: '🌊 Wspólny',
    typeAll: 'Typ: wszystkie', typeMono: 'Kawalerka', typeAppart: 'Apartament', typeVilla: 'Willa',
    filtriBtn: 'Filtry', filtriTitle: 'Sortuj i filtruj', filtriApply: 'Zastosuj', filtriClear: 'Wyczyść wszystko',
    sortSection: 'Sortuj według', seaSection: 'Odległość od morza', poolSection: 'Basen', typeSection: 'Typ nieruchomości', bedsSection: 'Sypialnie',
    sortDefault: 'Domyślne', sortPriceLow: 'Cena rosnąco', sortPriceHigh: 'Cena malejąco', sortBiggest: 'Największy', sortSmallest: 'Najmniejszy',
    seaAll: 'Wszystkie', sea250: '250m od morza', sea2km: 'Wśród natury',
    bedsAny: 'Dowolna',
  },
};

// ─── Tipi filtro ─────────────────────────────────────────────────────────────
type FilterType = 'all' | 'priceLow' | 'priceHigh' | 'size' | 'sizeSmall';

// ─── Tipi API ────────────────────────────────────────────────────────────────
interface OfferItem { offerId: number; offerName: string; price: number; unitsAvailable: number; }
interface RoomOffers { roomId: number; propertyId: number; offers: OfferItem[]; }

// ─── Helpers ─────────────────────────────────────────────────────────────────
function calcNights(ci: string, co: string) {
  return Math.round((new Date(co).getTime() - new Date(ci).getTime()) / 86_400_000);
}
function fmt(price: number) {
  return new Intl.NumberFormat('it-IT', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(price);
}
function getPoolLabel(room: Room, ui: Record<string, string>) {
  return room.privatePool ? ui.privPool : room.sharedPool ? ui.sharedPool : ui.noPool;
}
function getLocationLabel(room: Room, ui: Record<string, string>) {
  const prop = getPropertyForRoom(room.roomId);
  return prop?.propertyId === 46871 ? ui.nearSea : ui.nature;
}
// Formato data compatto per box riassunto: "8 apr"
const MSHORT: Record<string, string[]> = {
  it: ['gen','feb','mar','apr','mag','giu','lug','ago','set','ott','nov','dic'],
  en: ['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'],
  de: ['jan','feb','mär','apr','mai','jun','jul','aug','sep','okt','nov','dez'],
  pl: ['sty','lut','mar','kwi','maj','cze','lip','sie','wrz','paź','lis','gru'],
};
function fmtShort(ymd: string, loc: string): string {
  const [y, m, d] = ymd.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  return `${dt.getDate()} ${(MSHORT[loc] ?? MSHORT.it)[dt.getMonth()]}`;
}

// ─── Floor label multilingue ─────────────────────────────────────────────────
const FLOOR_LABELS: Record<string, { ground: string; floor: string; basement: string }> = {
  it: { ground: 'Piano terra', floor: 'Piano',       basement: 'Seminterrato' },
  en: { ground: 'Ground floor', floor: 'Floor',      basement: 'Basement' },
  de: { ground: 'Erdgeschoss',  floor: 'Etage',      basement: 'Untergeschoss' },
  pl: { ground: 'Parter',       floor: 'Piętro',     basement: 'Piwnica' },
};
function getFloorLabel(room: Room, loc: string): string {
  const fl = FLOOR_LABELS[loc] ?? FLOOR_LABELS.it;
  if (room.floor < 0) return fl.basement;
  if (room.floor === 0) return fl.ground;
  return `${fl.floor} ${room.floor}`;
}

function getMinPrice(ro: RoomOffers): number {
  const avail = ro.offers.filter(o => o.unitsAvailable > 0);
  if (avail.length === 0) return Infinity;
  return Math.min(...avail.map(o => o.price));
}

// ─── Componente principale ───────────────────────────────────────────────────
interface Props { locale?: string; onBack?: () => void; }

export default function WizardStep1({ locale = 'it', onBack }: Props) {
  const t = UI[locale] ?? UI.it;
  const loc = locale in UI ? locale : 'it';
  const router = useRouter();

  const {
    numAdult, numChild, childrenAges, checkIn, checkOut, poolPreference, setPoolPreference,
    selectedRoomId, setSelectedRoomId,
    selectedOfferId, setSelectedOfferId, setOffers,
    nextStep, prevStep,
  } = useWizardStore();

  const isSingleRoom = false;

  const [roomOffers, setRoomOffers]       = useState<RoomOffers[]>([]);
  const [coverUrls, setCoverUrls]         = useState<Record<number, string>>({});
  const [loading, setLoading]             = useState(true);
  const [error, setError]                 = useState<string | null>(null);
  const [pickedRoomId, setPickedRoomId]   = useState<number | null>(null);
  const [pickedOfferId, setPickedOfferId] = useState<number | null>(null);
  const [expandedRoomId, setExpandedRoomId] = useState<number | null>(null);
  const [activeFilter, setActiveFilter]   = useState<FilterType>('all');
  const [activeTypeFilter, setActiveTypeFilter] = useState<'all'|'monolocale'|'appartamento'|'villa'>('all');
  const [showFilterPanel, setShowFilterPanel] = useState(false);
  const [activeSeaFilter, setActiveSeaFilter] = useState<'all'|'sea'|'nature'>('all');
  const [activeBedsFilter, setActiveBedsFilter] = useState<0|1|2|3|4>(0);
  const [isDesk, setIsDesk]               = useState(false);

  const nights = checkIn && checkOut ? calcNights(checkIn, checkOut) : 0;
  const childrenTaxable = (childrenAges ?? []).filter((a: number) => a >= 12).length;
  const taxableAdults   = numAdult + childrenTaxable;
  const taxableNights   = Math.min(nights, 10);
  const touristTax      = taxableNights * taxableAdults * 2;

  // ── Fetch offerte ────────────────────────────────────────────────────────
  const fetchOffers = useCallback(async () => {
    if (!checkIn || !checkOut) {
      setError('Torna indietro e seleziona le date.');
      setLoading(false); return;
    }
    setLoading(true); setError(null); setRoomOffers([]);
    try {
      let targetRoomIds: number[];
      if (isSingleRoom) {
        targetRoomIds = [];
      } else {
        const total = numAdult + numChild;
        targetRoomIds = getAvailableRooms(total, poolPreference).map(r => r.roomId);
      }
      if (targetRoomIds.length === 0) { setLoading(false); return; }

      // ⚠️ numChildren NON va passato a Beds24 — i bambini 0-2 non influenzano il prezzo.
      // I bambini 3-17 vengono contati come adulti (passano come numAdults).
      // Passare numChildren causa l'applicazione di una tariffa bambini non prevista.
      const numAdultsForBeds24 = numAdult + (childrenAges ?? []).filter((a: number) => a >= 3).length;
      const qs = new URLSearchParams({
        roomIds:   targetRoomIds.join(','),
        arrival:   checkIn,
        departure: checkOut,
        numAdults: String(numAdultsForBeds24),
      });

      const res = await fetch(`/api/offers?${qs}`);
      if (!res.ok) { const b = await res.json().catch(() => ({})); throw new Error(b.error ?? `HTTP ${res.status}`); }
      const data = await res.json();
      const list: RoomOffers[] = (data.data ?? []).filter((x: RoomOffers) => x.offers?.length > 0);
      setRoomOffers(list);
      if (typeof setOffers === 'function') setOffers(list);
    } catch (e: any) {
      setError(e.message ?? 'Errore sconosciuto');
    } finally {
      setLoading(false);
    }
  }, [checkIn, checkOut, numAdult, numChild, childrenAges, poolPreference]);

  useEffect(() => { fetchOffers(); }, [fetchOffers]);

  useEffect(() => {
    const check = () => setIsDesk(window.innerWidth >= 768);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  // ── Fetch cover foto ─────────────────────────────────────────────────────
  useEffect(() => {
    if (isSingleRoom || roomOffers.length === 0) return;
    (async () => {
      const res = await fetch('/api/cloudinary?covers=true').catch(() => null);
      if (!res?.ok) return;
      const data = await res.json();
      const covers: Record<number, string> = {};
      for (const ro of roomOffers) {
        const room = PROPERTIES.flatMap(p => p.rooms).find(r => r.roomId === ro.roomId);
        if (room && data.covers?.[room.cloudinaryFolder]) {
          covers[ro.roomId] = data.covers[room.cloudinaryFolder];
        }
      }
      setCoverUrls(covers);
    })();
  }, [roomOffers, isSingleRoom]);

  // ── Filtra e ordina ───────────────────────────────────────────────────────
  const filteredRoomOffers = (() => {
    let list = [...roomOffers];

    // Filtro distanza mare
    if (activeSeaFilter === 'sea') {
      list = list.filter(ro => ro.propertyId === 46871);
    } else if (activeSeaFilter === 'nature') {
      list = list.filter(ro => ro.propertyId === 46487);
    }

    // Filtro tipo
    if (activeTypeFilter !== 'all') {
      list = list.filter(ro => {
        const room = PROPERTIES.flatMap(p => p.rooms).find(r => r.roomId === ro.roomId);
        return room?.type === activeTypeFilter;
      });
    }

    // Filtro camere da letto
    if (activeBedsFilter > 0) {
      list = list.filter(ro => {
        const room = PROPERTIES.flatMap(p => p.rooms).find(r => r.roomId === ro.roomId);
        return (room?.bedrooms ?? 0) >= activeBedsFilter;
      });
    }

    // Ordina
    if (activeFilter === 'priceLow') {
      list.sort((a, b) => getMinPrice(a) - getMinPrice(b));
    } else if (activeFilter === 'priceHigh') {
      list.sort((a, b) => getMinPrice(b) - getMinPrice(a));
    } else if (activeFilter === 'size') {
      list.sort((a, b) => {
        const roomA = PROPERTIES.flatMap(p => p.rooms).find(r => r.roomId === a.roomId);
        const roomB = PROPERTIES.flatMap(p => p.rooms).find(r => r.roomId === b.roomId);
        return (roomB?.sqm ?? 0) - (roomA?.sqm ?? 0);
      });
    } else if (activeFilter === 'sizeSmall') {
      list.sort((a, b) => {
        const roomA = PROPERTIES.flatMap(p => p.rooms).find(r => r.roomId === a.roomId);
        const roomB = PROPERTIES.flatMap(p => p.rooms).find(r => r.roomId === b.roomId);
        return (roomA?.sqm ?? 0) - (roomB?.sqm ?? 0);
      });
    }

    return list;
  })();

  // ── Selezione ────────────────────────────────────────────────────────────
  function pick(rId: number, oId: number) {
    setPickedRoomId(rId);
    setPickedOfferId(oId);
    setSelectedRoomId(rId);
    setSelectedOfferId(oId);
  }
  function handleContinua() {
    if (!pickedRoomId || !pickedOfferId) return;
    nextStep();
  }
  const canContinue = !!pickedRoomId && !!pickedOfferId;

  // ── Flags disponibilità filtri ───────────────────────────────────────────
  const hasSea    = roomOffers.some(ro => ro.propertyId === 46871);
  const hasNature = roomOffers.some(ro => ro.propertyId === 46487);
  const hasSeaFilter = hasSea && hasNature;
  const hasMono   = roomOffers.some(ro => PROPERTIES.flatMap(p => p.rooms).find(r => r.roomId === ro.roomId)?.type === 'monolocale');
  const hasAppart = roomOffers.some(ro => PROPERTIES.flatMap(p => p.rooms).find(r => r.roomId === ro.roomId)?.type === 'appartamento');
  const hasVilla  = roomOffers.some(ro => PROPERTIES.flatMap(p => p.rooms).find(r => r.roomId === ro.roomId)?.type === 'villa');
  const hasMultipleTypes = [hasMono, hasAppart, hasVilla].filter(Boolean).length > 1;

  // Conteggio filtri attivi (per badge bottone)
  const activeFiltersCount = [
    activeFilter !== 'all' ? 1 : 0,
    activeSeaFilter !== 'all' ? 1 : 0,
    poolPreference !== 'none' ? 1 : 0,
    activeTypeFilter !== 'all' ? 1 : 0,
    activeBedsFilter > 0 ? 1 : 0,
  ].reduce((a, b) => a + b, 0);

  function resetAllFilters() {
    setActiveFilter('all');
    setActiveSeaFilter('all');
    setPoolPreference('none');
    setActiveTypeFilter('all');
    setActiveBedsFilter(0);
  }

  // ─────────────────────────────────────────────────────────────────────────
  return (
    <div style={{ padding: '0 2px', fontFamily: 'sans-serif' }}>

      {/* ── Box riassunto prenotazione stile Expedia ── */}
      {checkIn && checkOut && (
        <div style={{
          background: '#fff',
          border: '1.5px solid #e5e7eb',
          borderRadius: 14,
          padding: '14px 16px',
          marginBottom: 16,
          boxShadow: '0 1px 6px rgba(0,0,0,0.06)',
        }}>
          {/* Date e modifica */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <div>
              <div style={{ fontWeight: 700, fontSize: 16, color: '#111' }}>
                {fmtShort(checkIn, loc)} – {fmtShort(checkOut, loc)}
              </div>
              <div style={{ fontSize: 13, color: '#666', marginTop: 2 }}>
                {nights} {nights === 1 ? t.nightsSing : t.nightsPlur}
                {' · '}
                {numAdult} {locale === 'it' ? (numAdult === 1 ? 'adulto' : 'adulti') : locale === 'de' ? 'Erw.' : locale === 'pl' ? 'dorosłych' : (numAdult === 1 ? 'adult' : 'adults')}
                {numChild > 0 && (
                  <>, {numChild} {locale === 'it' ? (numChild === 1 ? 'bambino' : 'bambini') : locale === 'de' ? (numChild === 1 ? 'Kind' : 'Kinder') : locale === 'pl' ? 'dzieci' : (numChild === 1 ? 'child' : 'children')}
                  {(() => {
                    const ages = (childrenAges ?? []).slice(0, numChild).filter((a: number) => a >= 0);
                    if (ages.length !== numChild) return null;
                    const suffix = locale === 'it' || locale === 'de' ? 'a' : locale === 'pl' ? 'l' : 'y';
                    return ` (${ages.map((a: number) => `${a}${suffix}`).join(', ')})`;
                  })()}</>
                )}
              </div>
            </div>
            <button
              onClick={onBack ?? prevStep}
              style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', display: 'flex', alignItems: 'center' }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1E73BE" strokeWidth="1.8">
                <path d="M11 4H4v7"/><path d="M4 4l7 7"/><path d="M20 20v-7h-7"/><path d="M20 20l-7-7"/>
              </svg>
            </button>
          </div>
        </div>
      )}

      <h2 style={{ color: '#1E73BE', fontSize: 21, fontWeight: 700, margin: '0 0 12px' }}>
        {isSingleRoom ? t.titleSingle : t.titleMulti}
      </h2>

      {/* ── Filtri ── */}
      {!isSingleRoom && !loading && !error && roomOffers.length > 0 && (
        <div style={{ marginBottom: 16 }}>

          {/* Riga: bottone Filtri + chip filtri attivi */}
          <div style={{ display: 'flex', gap: 8, alignItems: 'center', overflowX: 'auto', scrollbarWidth: 'none' }}>

            {/* Bottone Filtri */}
            <button
              onClick={() => setShowFilterPanel(true)}
              style={{
                display: 'flex', alignItems: 'center', gap: 7,
                padding: '8px 16px', borderRadius: 24, flexShrink: 0,
                border: activeFiltersCount > 0 ? '1.5px solid #FCAF1A' : '1.5px solid #333',
                background: activeFiltersCount > 0 ? '#FCAF1A' : '#fff',
                color: activeFiltersCount > 0 ? '#fff' : '#111',
                fontSize: 14, fontWeight: 600, cursor: 'pointer',
              }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <line x1="4" y1="6" x2="20" y2="6"/><line x1="8" y1="12" x2="20" y2="12"/><line x1="12" y1="18" x2="20" y2="18"/>
              </svg>
              {t.filtriBtn}
              {activeFiltersCount > 0 && (
                <span style={{
                  background: 'rgba(255,255,255,0.9)', color: '#B07820',
                  borderRadius: '50%', width: 20, height: 20,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 11, fontWeight: 700, flexShrink: 0,
                }}>
                  {activeFiltersCount}
                </span>
              )}
            </button>

            {/* Chip filtri attivi */}
            {activeFilter !== 'all' && (
              <button onClick={() => setActiveFilter('all')} style={chipActiveStyle}>
                {activeFilter === 'priceLow' ? t.sortPriceLow : activeFilter === 'priceHigh' ? t.sortPriceHigh : activeFilter === 'size' ? t.sortBiggest : t.sortSmallest}
                <span style={{ fontSize: 15, lineHeight: 1 }}>×</span>
              </button>
            )}
            {activeSeaFilter !== 'all' && (
              <button onClick={() => setActiveSeaFilter('all')} style={chipActiveStyle}>
                {activeSeaFilter === 'sea' ? t.sea250 : t.sea2km}
                <span style={{ fontSize: 15, lineHeight: 1 }}>×</span>
              </button>
            )}
            {poolPreference !== 'none' && (
              <button onClick={() => setPoolPreference('none')} style={chipActiveStyle}>
                {poolPreference === 'private' ? t.poolPrivate : t.poolShared}
                <span style={{ fontSize: 15, lineHeight: 1 }}>×</span>
              </button>
            )}
            {activeTypeFilter !== 'all' && (
              <button onClick={() => setActiveTypeFilter('all')} style={chipActiveStyle}>
                {activeTypeFilter === 'monolocale' ? t.typeMono : activeTypeFilter === 'appartamento' ? t.typeAppart : t.typeVilla}
                <span style={{ fontSize: 15, lineHeight: 1 }}>×</span>
              </button>
            )}
            {activeBedsFilter > 0 && (
              <button onClick={() => setActiveBedsFilter(0)} style={chipActiveStyle}>
                {activeBedsFilter}+ {t.camere}
                <span style={{ fontSize: 15, lineHeight: 1 }}>×</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* ── Panel filtri: modal su desktop, bottom sheet su mobile ── */}
      {showFilterPanel && (
        <>
          {/* Overlay */}
          <div
            onClick={() => setShowFilterPanel(false)}
            style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 300 }}
          />

          {/* Contenitore: centrato su desktop, bottom sheet su mobile */}
          <div style={{
            position: 'fixed', zIndex: 301,
            ...(isDesk ? {
              top: '50%', left: '50%',
              transform: 'translate(-50%, -50%)',
              width: 560, maxWidth: '90vw',
              borderRadius: 16,
              maxHeight: '85vh',
            } : {
              bottom: 0, left: 0, right: 0,
              borderRadius: '20px 20px 0 0',
              height: '85vh',
            }),
            background: '#fff',
            boxShadow: '0 8px 40px rgba(0,0,0,0.18)',
            display: 'flex', flexDirection: 'column',
            overflow: 'hidden',
          }}>

            {/* Header fisso */}
            <div style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              padding: '16px 20px', borderBottom: '1px solid #f0f0f0', flexShrink: 0,
            }}>
              <button
                onClick={() => setShowFilterPanel(false)}
                style={{ width: 32, height: 32, borderRadius: '50%', border: '1.5px solid #333',
                  background: '#fff', cursor: 'pointer', display: 'flex', alignItems: 'center',
                  justifyContent: 'center', fontSize: 18, flexShrink: 0 }}>
                ×
              </button>
              <span style={{ fontWeight: 700, fontSize: 16 }}>{t.filtriTitle}</span>
              <button
                onClick={resetAllFilters}
                style={{ background: 'none', border: 'none', color: '#1E73BE', fontSize: 14,
                  fontWeight: 600, cursor: 'pointer', textDecoration: 'underline' }}>
                {t.filtriClear}
              </button>
            </div>

            {/* Corpo scrollabile */}
            <div style={{ flex: 1, overflowY: 'scroll', WebkitOverflowScrolling: 'touch', padding: '0 20px' }}>

              {/* ── 1. Ordina per ── */}
              <div style={sectionStyle}>
                <div style={sectionTitleStyle}>{t.sortSection}</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
                  {([
                    { key: 'all'       as FilterType, label: t.sortDefault },
                    { key: 'priceLow'  as FilterType, label: t.sortPriceLow },
                    { key: 'priceHigh' as FilterType, label: t.sortPriceHigh },
                    { key: 'size'      as FilterType, label: t.sortBiggest },
                    { key: 'sizeSmall' as FilterType, label: t.sortSmallest },
                  ]).map(({ key, label }) => (
                    <button key={key} onClick={() => setActiveFilter(key)} style={radioRowStyle}>
                      <span style={{ fontSize: 15, color: activeFilter === key ? '#1E73BE' : '#111', fontWeight: activeFilter === key ? 600 : 400 }}>{label}</span>
                      <div style={{
                        width: 20, height: 20, borderRadius: '50%', flexShrink: 0,
                        border: `2px solid ${activeFilter === key ? '#1E73BE' : '#ccc'}`,
                        background: activeFilter === key ? '#1E73BE' : '#fff',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                      }}>
                        {activeFilter === key && <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#fff' }} />}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <div style={dividerStyle} />

              {/* ── 2. Distanza dal mare (solo se entrambe le proprietà disponibili) ── */}
              {hasSeaFilter && (
                <>
                  <div style={sectionStyle}>
                    <div style={sectionTitleStyle}>{t.seaSection}</div>
                    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                      {([
                        { key: 'all'    as const, label: t.seaAll },
                        { key: 'sea'    as const, label: t.sea250 },
                        { key: 'nature' as const, label: t.sea2km },
                      ]).map(({ key, label }) => (
                        <button key={key} onClick={() => setActiveSeaFilter(key)} style={pillStyle(activeSeaFilter === key)}>
                          {label}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div style={dividerStyle} />
                </>
              )}

              {/* ── 3. Piscina ── */}
              <div style={sectionStyle}>
                <div style={sectionTitleStyle}>{t.poolSection}</div>
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  {([
                    { val: 'none'    as const, label: locale === 'it' ? 'Tutte' : locale === 'de' ? 'Tutte' : locale === 'pl' ? 'Wszystkie' : 'All' },
                    { val: 'private' as const, label: t.poolPrivate },
                    { val: 'shared'  as const, label: t.poolShared },
                  ]).map(({ val, label }) => (
                    <button key={val} onClick={() => setPoolPreference(val)} style={pillStyle(poolPreference === val)}>
                      {label}
                    </button>
                  ))}
                </div>
                {poolPreference !== 'none' && (
                  <div style={{
                    marginTop: 10, padding: '9px 12px', borderRadius: 8,
                    background: '#FFF8EC', border: '1px solid #FCAF1A',
                    display: 'flex', alignItems: 'flex-start', gap: 8,
                  }}>
                    <span style={{ fontSize: 14, flexShrink: 0 }}>🏊</span>
                    <span style={{ fontSize: 12, color: '#B07820', lineHeight: 1.5 }}>
                      {locale === 'it' ? 'La piscina è aperta indicativamente da fine maggio a metà ottobre.' :
                       locale === 'de' ? 'Der Pool ist voraussichtlich von Ende Mai bis Mitte Oktober geöffnet.' :
                       locale === 'pl' ? 'Basen jest czynny orientacyjnie od końca maja do połowy października.' :
                       'The pool is generally open from late May to mid-October.'}
                    </span>
                  </div>
                )}
              </div>

              {/* ── 4. Tipo di casa (solo se più tipi disponibili) ── */}
              {hasMultipleTypes && (
                <>
                  <div style={dividerStyle} />
                  <div style={sectionStyle}>
                    <div style={sectionTitleStyle}>{t.typeSection}</div>
                    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                      {([
                        { val: 'all'          as const, label: locale === 'it' ? 'Tutti' : locale === 'de' ? 'Alle' : locale === 'pl' ? 'Wszystkie' : 'All' },
                        ...(hasMono   ? [{ val: 'monolocale'   as const, label: t.typeMono }]   : []),
                        ...(hasAppart ? [{ val: 'appartamento' as const, label: t.typeAppart }] : []),
                        ...(hasVilla  ? [{ val: 'villa'        as const, label: t.typeVilla }]  : []),
                      ]).map(({ val, label }) => (
                        <button key={val} onClick={() => setActiveTypeFilter(val)} style={pillStyle(activeTypeFilter === val)}>
                          {label}
                        </button>
                      ))}
                    </div>
                  </div>
                </>
              )}

              {/* ── 5. Camere da letto ── */}
              <div style={dividerStyle} />
              <div style={sectionStyle}>
                <div style={sectionTitleStyle}>{t.bedsSection}</div>
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  {([
                    { val: 0 as const, label: t.bedsAny },
                    { val: 1 as const, label: '1+' },
                    { val: 2 as const, label: '2+' },
                    { val: 3 as const, label: '3+' },
                    { val: 4 as const, label: '4+' },
                  ]).map(({ val, label }) => (
                    <button key={val} onClick={() => setActiveBedsFilter(val)} style={pillStyle(activeBedsFilter === val)}>
                      {label}
                    </button>
                  ))}
                </div>
              </div>

              <div style={{ height: 24 }} />
            </div>

            {/* Footer fisso */}
            <div style={{ flexShrink: 0, background: '#fff', padding: '14px 20px 28px', borderTop: '1px solid #f0f0f0' }}>
              <button
                onClick={() => setShowFilterPanel(false)}
                style={{ width: '100%', padding: '13px', borderRadius: 10,
                  background: '#FCAF1A', color: '#fff', border: 'none', fontWeight: 700, fontSize: 15, cursor: 'pointer' }}>
                {t.filtriApply}{activeFiltersCount > 0 ? ` (${activeFiltersCount})` : ''}
              </button>
            </div>
          </div>
        </>
      )}

      {/* Spinner */}
      {loading && (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12, padding: '40px 0' }}>
          <div style={{ width: 38, height: 38, border: '3px solid #eee', borderTop: '3px solid #1E73BE', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
          <span style={{ color: '#888', fontSize: 13 }}>{t.loading}</span>
        </div>
      )}

      {/* Errore */}
      {!loading && error && (
        <div style={{ background: '#fff5f5', border: '1px solid #f5c6cb', borderRadius: 12, padding: '20px', textAlign: 'center', marginBottom: 16 }}>
          <p style={{ margin: '0 0 8px', fontWeight: 700, color: '#c0392b' }}>{t.errTitle}</p>
          <p style={{ margin: '0 0 14px', fontSize: 13, color: '#888' }}>{error}</p>
          {checkIn && checkOut && (
            <button onClick={fetchOffers} style={retryBtn}>{t.retry}</button>
          )}
        </div>
      )}

      {/* Nessun risultato */}
      {!loading && !error && filteredRoomOffers.length === 0 && (
        <div style={{ background: '#f5f5f5', borderRadius: 12, padding: '24px', textAlign: 'center', marginBottom: 16 }}>
          <p style={{ margin: 0, color: '#888', fontSize: 14 }}>{t.noResults}</p>
        </div>
      )}

      {/* Lista card rooms */}
      {!loading && !error && filteredRoomOffers.length > 0 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16, marginBottom: 20 }}>
          {filteredRoomOffers.map(ro => {
            const room = PROPERTIES.flatMap(p => p.rooms).find(r => r.roomId === ro.roomId);
            if (!room) return null;
            const isRoomPicked = pickedRoomId === room.roomId;
            const coverUrl = coverUrls[room.roomId];

            return (
              <div key={room.roomId} style={{
                border: `2px solid ${isRoomPicked ? '#1E73BE' : '#e5e7eb'}`,
                borderRadius: 16, overflow: 'hidden', background: '#fff',
                boxShadow: isRoomPicked ? '0 0 0 3px rgba(30,115,190,0.12)' : '0 1px 4px rgba(0,0,0,0.06)',
                transition: 'all 0.15s',
              }}>

                {/* ── Layout VRBO: 3 colonne su desktop, verticale su mobile ── */}
                <div className="s5-card-row">

                  {/* COL 1: Foto — solo WizardLibero */}
                  {!isSingleRoom && (
                    <div className="s5-card-photo" style={{ background: '#f0f4f8', position: 'relative', overflow: 'hidden', flexShrink: 0 }}>
                      <div
                        onClick={e => { e.stopPropagation(); router.push(`/${locale}/residenze/${room.slug}`); }}
                        style={{ display: 'block', width: '100%', height: '100%', cursor: 'pointer' }}
                      >
                        {coverUrl ? (
                          <img src={coverUrl} alt={room.name} style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }} loading="lazy" />
                        ) : (
                          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', color: '#ccc', fontSize: 24 }}>🏠</div>
                        )}
                      </div>
                      <span style={{ position: 'absolute', top: 10, left: 10, background: 'rgba(0,0,0,0.55)', color: '#fff', fontSize: 11, fontWeight: 600, padding: '3px 10px', borderRadius: 20, pointerEvents: 'none' }}>
                        {getFloorLabel(room, loc)}
                      </span>
                    </div>
                  )}

                  {/* COL 2: Nome + dettagli */}
                  <div className="s5-card-details" style={{ flex: 1, minWidth: 0, padding: '16px', borderBottom: '1px solid #f0f0f0' }}>
                    <div style={{ fontSize: 18, fontWeight: 700, color: '#1E73BE', marginBottom: 8 }}>{room.name}</div>
                    {isSingleRoom && <span style={{ fontSize: 11, color: '#888', background: '#f0f0f0', borderRadius: 6, padding: '2px 8px', marginBottom: 8, display: 'inline-block' }}>{room.type}</span>}
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                      <span style={chip}>🛏️ {room.bedrooms} {t.camere}</span>
                      <span style={chip}>👥 {t.maxPers} {room.maxPeople} {t.persone}</span>
                      <span style={chip}>📐 {room.sqm} mq</span>
                      <span style={chip}>{getPoolLabel(room, t)}</span>
                      <span style={chip}>📍 {getLocationLabel(room, t)}</span>
                    </div>
                  </div>

                  {/* COL 3: Tariffe */}
                  <div className="s5-card-offers">
                    {(() => {
                      const availOffers = ro.offers.filter(o => o.unitsAvailable > 0);
                      const minOffer = availOffers.length > 0
                        ? availOffers.reduce((a, b) => a.price < b.price ? a : b)
                        : ro.offers[0];
                      const isExpanded = !isDesk || expandedRoomId === room.roomId || isRoomPicked;
                      const offersToShow = isExpanded ? ro.offers : (minOffer ? [minOffer] : ro.offers);

                      return (
                        <>
                          {offersToShow.map(offer => {
                            const isPicked = isRoomPicked && pickedOfferId === offer.offerId;
                            const perNight = nights > 0 ? Math.round(offer.price / nights) : 0;
                            const name = OFFER_NAMES[offer.offerId]?.[loc] ?? offer.offerName;
                            const desc = OFFER_DESC[offer.offerId]?.[loc];
                            const avail = offer.unitsAvailable > 0;
                            return (
                              <button key={offer.offerId}
                                onClick={() => avail && pick(room.roomId, offer.offerId)}
                                disabled={!avail}
                                style={{
                                  width: '100%', textAlign: 'left',
                                  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                                  padding: '10px 14px', marginBottom: 6, borderRadius: 10,
                                  border: isPicked ? '2px solid #1E73BE' : '1.5px solid #e5e7eb',
                                  background: isPicked ? '#EEF5FC' : '#fff',
                                  cursor: avail ? 'pointer' : 'default',
                                  opacity: avail ? 1 : 0.4, transition: 'all 0.12s',
                                }}>
                                <div style={{ flex: 1, marginRight: 10, minWidth: 0 }}>
                                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                                    <span style={{ fontSize: 13, fontWeight: 700, color: '#111' }}>{name}</span>
                                    {isPicked && <span style={{ fontSize: 11, color: '#1E73BE', fontWeight: 700 }}>{t.selezionata}</span>}
                                  </div>
                                  {desc && <p style={{ margin: '2px 0 0', fontSize: 11, color: '#666', lineHeight: 1.3 }}>{desc}</p>}
                                  {!avail && <span style={{ fontSize: 11, color: '#e74c3c', display: 'block', marginTop: 2 }}>{t.nonDisp}</span>}
                                </div>
                                <div style={{ textAlign: 'right', flexShrink: 0 }}>
                                  <div style={{ fontSize: 19, fontWeight: 800, color: '#1E73BE', lineHeight: 1 }}>{fmt(offer.price + touristTax)}</div>
                                  {perNight > 0 && <div style={{ fontSize: 11, color: '#999', marginTop: 1 }}>{fmt(perNight)}{t.perNight}</div>}
                                  <div style={{ fontSize: 10, color: '#bbb', marginTop: 1 }}>{t.total}</div>
                                </div>
                              </button>
                            );
                          })}
                          {/* Bottone espandi/comprimi — solo desktop, solo se ci sono più tariffe */}
                          {isDesk && ro.offers.length > 1 && !isRoomPicked && (
                            <button
                              onClick={() => setExpandedRoomId(expandedRoomId === room.roomId ? null : room.roomId)}
                              style={{ width: '100%', background: 'none', border: 'none', color: '#1E73BE', fontSize: 12, fontWeight: 600, cursor: 'pointer', padding: '4px 0', textAlign: 'center' }}>
                              {isExpanded
                                ? (locale === 'it' ? 'Meno tariffe ▴' : locale === 'de' ? 'Weniger ▴' : locale === 'pl' ? 'Mniej ▴' : 'Less ▴')
                                : (locale === 'it' ? `Vedi tutte le tariffe (${ro.offers.length}) ▾` : locale === 'de' ? `Alle Tarife (${ro.offers.length}) ▾` : locale === 'pl' ? `Wszystkie taryfy (${ro.offers.length}) ▾` : `View all rates (${ro.offers.length}) ▾`)}
                            </button>
                          )}
                        </>
                      );
                    })()}
                  </div>{/* fine s5-card-offers */}

                </div>{/* fine s5-card-row */}
              </div>
            );
          })}
        </div>
      )}

      {/* CTA mobile */}
      {/* ← Indietro */}
      <button onClick={onBack ?? prevStep} style={{ background: 'none', border: 'none', color: '#1E73BE', fontSize: 14, cursor: 'pointer', padding: '12px 0 80px', display: 'block' }}>
        {t.indietro}
      </button>

      {/* CTA mobile sticky */}
      <div style={{
        position: 'fixed', bottom: 0, left: 0, right: 0,
        background: '#fff', borderTop: '1px solid #e5e7eb',
        padding: '12px 16px 28px', zIndex: 50,
      }} className="step1-cta-mobile">
        <button onClick={handleContinua} disabled={!canContinue} style={{
          width: '100%', padding: '15px', borderRadius: 12, border: 'none',
          fontSize: 16, fontWeight: 700,
          background: canContinue ? '#FCAF1A' : '#e0e0e0',
          color: canContinue ? '#fff' : '#999',
          cursor: canContinue ? 'pointer' : 'not-allowed',
        }}>
          {t.continua}
        </button>
      </div>
      <style>{'@media (min-width: 768px) { .step1-cta-mobile { display: none !important; } }'}</style>

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }

        /* MOBILE default: verticale */
        .s5-card-row { display: flex; flex-direction: column; }
        .s5-card-photo { width: 100%; height: 180px; }
        .s5-card-details { border-right: none; }
        .s5-card-offers { padding: 8px 12px 14px; }

        /* DESKTOP: VRBO 3 colonne */
        @media (min-width: 768px) {
          .s5-card-row { flex-direction: row; align-items: stretch; }
          .s5-card-photo { width: 220px; height: auto; min-height: 180px; }
          .s5-card-details { border-bottom: none !important; border-right: 1px solid #f0f0f0; flex: 1; }
          .s5-card-offers { width: 260px; flex-shrink: 0; padding: 16px 14px; display: flex; flex-direction: column; justify-content: center; }
        }
      `}</style>
    </div>
  );
}

const chipActiveStyle: React.CSSProperties = {
  display: 'flex', alignItems: 'center', gap: 5,
  padding: '6px 11px', borderRadius: 20, flexShrink: 0,
  border: '1.5px solid #1E73BE', background: '#EEF5FC',
  color: '#1E73BE', fontSize: 12, fontWeight: 600, cursor: 'pointer',
};
const sectionStyle: React.CSSProperties = {
  paddingTop: 14, paddingBottom: 10,
};
const sectionTitleStyle: React.CSSProperties = {
  fontWeight: 700, fontSize: 13, color: '#111', marginBottom: 10,
};
const radioRowStyle: React.CSSProperties = {
  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
  width: '100%', padding: '9px 0', background: 'none', border: 'none',
  borderBottom: '1px solid #f0f0f0', cursor: 'pointer', textAlign: 'left',
};
const dividerStyle: React.CSSProperties = {
  height: 1, background: '#e5e7eb',
};
const pillStyle = (active: boolean): React.CSSProperties => ({
  padding: '7px 14px', borderRadius: 8, fontSize: 13, cursor: 'pointer', fontWeight: active ? 600 : 400,
  border: `1.5px solid ${active ? '#1E73BE' : '#e5e7eb'}`,
  background: active ? '#EEF5FC' : '#f5f5f5',
  color: active ? '#1E73BE' : '#555',
});

const chip: React.CSSProperties = {
  fontSize: 11, color: '#555', background: '#f5f5f5', borderRadius: 6, padding: '3px 8px',
};
const retryBtn: React.CSSProperties = {
  padding: '8px 20px', borderRadius: 8, border: '1px solid #1E73BE',
  background: '#fff', color: '#1E73BE', fontSize: 14, cursor: 'pointer',
};
