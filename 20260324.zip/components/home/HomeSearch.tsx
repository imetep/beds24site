'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { useWizardStore } from '@/store/wizard-store';
import { PROPERTIES } from '@/config/properties';

// ─── Traduzioni ───────────────────────────────────────────────────────────────
const UI: Record<string, Record<string, string>> = {
  it: { dates:'Date', guests:'Persone', search:'Cerca',
        checkin:'Check-in', checkout:'Check-out', done:'Fatto',
        adults:'Adulti', adultsAge:'18+', children:'Bambini', childrenAge:'0–17',
        nights:'notte', nightsP:'notti', hintCI:'Seleziona check-in',
        hintCO:'Seleziona check-out', cancel:'Cancella',
        sliderTitle:'Le nostre soluzioni', dintorniTitle:'Dintorni' },
  en: { dates:'Dates', guests:'Guests', search:'Search',
        checkin:'Check-in', checkout:'Check-out', done:'Done',
        adults:'Adults', adultsAge:'18+', children:'Children', childrenAge:'0–17',
        nights:'night', nightsP:'nights', hintCI:'Select check-in',
        hintCO:'Select check-out', cancel:'Clear',
        sliderTitle:'Our solutions', dintorniTitle:'Surroundings' },
  de: { dates:'Datum', guests:'Personen', search:'Suchen',
        checkin:'Check-in', checkout:'Check-out', done:'Fertig',
        adults:'Erwachsene', adultsAge:'18+', children:'Kinder', childrenAge:'0–17',
        nights:'Nacht', nightsP:'Nächte', hintCI:'Check-in wählen',
        hintCO:'Check-out wählen', cancel:'Löschen',
        sliderTitle:'Unsere Lösungen', dintorniTitle:'Umgebung' },
  pl: { dates:'Daty', guests:'Osoby', search:'Szukaj',
        checkin:'Zameldowanie', checkout:'Wymeldowanie', done:'Gotowe',
        adults:'Dorośli', adultsAge:'18+', children:'Dzieci', childrenAge:'0–17',
        nights:'noc', nightsP:'nocy', hintCI:'Wybierz zameldowanie',
        hintCO:'Wybierz wymeldowanie', cancel:'Wyczyść',
        sliderTitle:'Nasze rozwiązania', dintorniTitle:'Okolice' },
};

const MONTHS: Record<string, string[]> = {
  it: ['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'],
  en: ['January','February','March','April','May','June','July','August','September','October','November','December'],
  de: ['Januar','Februar','März','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember'],
  pl: ['Styczeń','Luty','Marzec','Kwiecień','Maj','Czerwiec','Lipiec','Sierpień','Wrzesień','Październik','Listopad','Grudzień'],
};
const DAYS: Record<string, string[]> = {
  it: ['Lu','Ma','Me','Gi','Ve','Sa','Do'],
  en: ['Mo','Tu','We','Th','Fr','Sa','Su'],
  de: ['Mo','Di','Mi','Do','Fr','Sa','So'],
  pl: ['Pn','Wt','Śr','Cz','Pt','So','Nd'],
};

// ─── Helpers ──────────────────────────────────────────────────────────────────
function toYMD(y: number, m: number, d: number) {
  return `${y}-${String(m + 1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
}
function parseYMD(s: string) {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(y, m - 1, d);
}
function diffNights(a: string, b: string) {
  return Math.round((parseYMD(b).getTime() - parseYMD(a).getTime()) / 86400000);
}
function addM(y: number, m: number, delta: number) {
  let nm = m + delta;
  const ny = y + Math.floor(nm / 12);
  nm = ((nm % 12) + 12) % 12;
  return { y: ny, m: nm };
}
function cells(year: number, month: number): (number | null)[] {
  const dow = new Date(year, month, 1).getDay();
  const off = dow === 0 ? 6 : dow - 1;
  const tot = new Date(year, month + 1, 0).getDate();
  const arr: (number | null)[] = Array(off).fill(null);
  for (let d = 1; d <= tot; d++) arr.push(d);
  return arr;
}
const WEEKDAYS: Record<string, string[]> = {
  it: ['dom','lun','mar','mer','gio','ven','sab'],
  en: ['sun','mon','tue','wed','thu','fri','sat'],
  de: ['so','mo','di','mi','do','fr','sa'],
  pl: ['nd','pn','wt','śr','cz','pt','so'],
};
const MONTHS_SHORT: Record<string, string[]> = {
  it: ['gen','feb','mar','apr','mag','giu','lug','ago','set','ott','nov','dic'],
  en: ['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'],
  de: ['jan','feb','mär','apr','mai','jun','jul','aug','sep','okt','nov','dez'],
  pl: ['sty','lut','mar','kwi','maj','cze','lip','sie','wrz','paź','lis','gru'],
};
function fmtDate(ymd: string, locale: string): string {
  const d = parseYMD(ymd);
  const wd  = (WEEKDAYS[locale]  ?? WEEKDAYS.it)[d.getDay()];
  const mon = (MONTHS_SHORT[locale] ?? MONTHS_SHORT.it)[d.getMonth()];
  return `${wd} ${d.getDate()} ${mon}`;
}

// ─── Padding costanti ─────────────────────────────────────────────────────────
const PAD_MOBILE  = 16;
const PAD_DESKTOP = 64;

// ─── Componente ───────────────────────────────────────────────────────────────
export default function HomeSearch({ locale }: { locale: string }) {
  const ui   = UI[locale] ?? UI.it;
  const mons = MONTHS[locale] ?? MONTHS.it;
  const dys  = DAYS[locale]   ?? DAYS.it;
  const router = useRouter();

  const { checkIn, checkOut, numAdult, numChild, childrenAges,
          setCheckIn, setCheckOut, setNumAdult, setNumChild, setChildAge } = useWizardStore();

  const [panel, setPanel]             = useState<'none' | 'dates' | 'guests'>('none');
  const [hover, setHover]             = useState<string | null>(null);
  const [isDesk, setDesk]             = useState(false);
  const [covers, setCovers]           = useState<Record<string, string>>({});
  const [dintorniPhotos, setDintorni] = useState<string[]>([]);
  const [lightboxSrc, setLightbox]    = useState<string | null>(null);
  const [showResArr, setShowResArr]   = useState(false);
  const [showDintArr, setShowDintArr] = useState(false);

  const residenzeRef = useRef<HTMLDivElement>(null);
  const dintorniRef  = useRef<HTMLDivElement>(null);

  // Calendario
  const now = new Date(); now.setHours(0, 0, 0, 0);
  const todayYMD = toYMD(now.getFullYear(), now.getMonth(), now.getDate());
  const [vy, setVY] = useState(now.getFullYear());
  const [vm, setVM] = useState(now.getMonth());
  const sec = addM(vy, vm, 1);

  useEffect(() => {
    const check = () => setDesk(window.innerWidth >= 768);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  useEffect(() => {
    document.body.style.overflow = (!isDesk && panel !== 'none') ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [panel, isDesk]);

  useEffect(() => {
    fetch('/api/cloudinary?covers=true')
      .then(r => r.json())
      .then(d => { if (d.covers) setCovers(d.covers); })
      .catch(() => {});
  }, []);

  useEffect(() => {
    fetch('/api/cloudinary?folder=generiche')
      .then(r => r.json())
      .then(d => {
        const raw: any[] = d.photos ?? [];
        const urls = raw.map((p: any) => p.url ?? p).filter(Boolean);
        if (urls.length > 0) setDintorni(urls);
      })
      .catch(() => {});
  }, []);

  // ── Calendario ─────────────────────────────────────────────────────────────
  const [selectingCheckout, setSelectingCheckout] = useState(false);
  const phase: 'ci' | 'co' = selectingCheckout ? 'co' : (checkIn && !checkOut ? 'co' : 'ci');
  const isPrevDis = toYMD(vy, vm, 1) <= toYMD(now.getFullYear(), now.getMonth(), 1);

  function handleDay(ymd: string) {
    if (ymd < todayYMD) return;
    if (phase === 'ci') {
      setCheckIn(ymd);
      const d = parseYMD(ymd);
      const pre = new Date(d.getTime() + 3 * 86400000);
      setCheckOut(toYMD(pre.getFullYear(), pre.getMonth(), pre.getDate()));
      setSelectingCheckout(true);
    } else {
      if (diffNights(checkIn!, ymd) < 1) return;
      setCheckOut(ymd);
      setSelectingCheckout(false);
    }
  }

  // renderMonth: showTitle=true solo su mobile (desktop usa la barra ‹ mese ›)
  function renderMonth(year: number, month: number, showTitle = true) {
    const rangeEnd = checkOut || hover;
    return (
      <div style={{ flex: 1 }}>
        {showTitle && (
          <div style={{ textAlign: 'center', fontWeight: 700, fontSize: 14, marginBottom: 8, color: '#111' }}>
            {mons[month]} {year}
          </div>
        )}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', marginBottom: 2 }}>
          {dys.map(d => (
            <div key={d} style={{ textAlign: 'center', fontSize: 10, fontWeight: 600, color: '#bbb', paddingBottom: 4 }}>{d}</div>
          ))}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)' }}>
          {cells(year, month).map((day, i) => {
            if (!day) return <div key={i} />;
            const ymd = toYMD(year, month, day);
            const isPast  = ymd < todayYMD;
            const isStart = ymd === checkIn;
            const isEnd   = ymd === checkOut;
            const inRange = !!(checkIn && rangeEnd && ymd > checkIn && ymd < rangeEnd);
            return (
              <button key={i} onClick={() => handleDay(ymd)}
                onMouseEnter={() => { if (!isPast) setHover(ymd); }}
                onMouseLeave={() => setHover(null)}
                disabled={isPast}
                style={{
                  height: 34, width: '100%', border: 'none', outline: 'none',
                  borderRadius: (isStart || isEnd) ? '50%' : 0,
                  background: (isStart || isEnd) ? '#1E73BE' : inRange ? '#EBF4FC' : 'transparent',
                  color: (isStart || isEnd) ? '#fff' : isPast ? '#ccc' : '#111',
                  fontSize: 13, fontWeight: (isStart || isEnd) ? 700 : 400,
                  cursor: isPast ? 'default' : 'pointer',
                  textDecoration: isPast ? 'line-through' : 'none',
                }}
              >{day}</button>
            );
          })}
        </div>
      </div>
    );
  }

  // ── Labels ─────────────────────────────────────────────────────────────────
  const nights = checkIn && checkOut ? diffNights(checkIn, checkOut) : 0;
  const datesLabel = checkIn && checkOut
    ? `${fmtDate(checkIn, locale)} – ${fmtDate(checkOut, locale)}  ·  ${nights} ${nights === 1 ? ui.nights : ui.nightsP}`
    : checkIn ? fmtDate(checkIn, locale) : null;
  const guestsLabel = (numAdult + numChild) > 0
    ? `${numAdult + numChild} ${locale === 'it' ? (numAdult + numChild === 1 ? 'persona' : 'persone') : locale === 'de' ? 'Personen' : locale === 'pl' ? 'os.' : 'guests'}`
    : null;

  function handleCerca() {
    if (!checkIn || !checkOut) { setPanel('dates'); return; }
    setPanel('none');
    router.push(`/${locale}/prenota?from=home`);
  }

  // Scroll di esattamente una card alla volta
  function scrollSlider(ref: React.RefObject<HTMLDivElement | null>, dir: 'left' | 'right') {
    const el = ref.current;
    if (!el) return;
    const first = el.firstElementChild as HTMLElement;
    const step = first ? first.offsetWidth + 14 : 220;
    el.scrollBy({ left: dir === 'right' ? step : -step, behavior: 'smooth' });
  }

  // ── Panel calendario ──────────────────────────────────────────────────────
  function CalContent() {
    const mobileMonths = Array.from({ length: 12 }, (_, i) => addM(now.getFullYear(), now.getMonth(), i));
    return (
      <div>
        <div style={{ padding: isDesk ? '24px 24px 0' : '0 20px', position: 'sticky', top: 0, background: '#fff', zIndex: 10, paddingTop: isDesk ? 24 : 0 }}>
          {!isDesk && <div style={{ width: 40, height: 4, borderRadius: 2, background: '#ddd', margin: '8px auto 16px' }} />}
          <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
            {[{l: ui.checkin, v: checkIn}, {l: ui.checkout, v: checkOut}].map(({l, v}, i) => (
              <div key={i} style={{ flex: 1, padding: '8px 10px', borderRadius: 10, border: `2px solid ${v ? '#1E73BE' : '#e5e7eb'}`, background: v ? '#EBF4FC' : '#f9fafb' }}>
                <div style={{ fontSize: 9, fontWeight: 700, color: '#888', textTransform: 'uppercase' }}>{l}</div>
                <div style={{ fontSize: 13, fontWeight: 600, color: v ? '#1E73BE' : '#aaa' }}>{v ? fmtDate(v, locale) : '—'}</div>
              </div>
            ))}
          </div>
          <p style={{ fontSize: 12, color: '#1E73BE', fontWeight: 500, margin: '0 0 8px' }}>
            {phase === 'ci' ? ui.hintCI : ui.hintCO}
          </p>
          {phase === 'co' && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, background: 'linear-gradient(135deg,#FFF8EC,#FFF3DC)', border: '1px solid #FCAF1A', borderLeft: '4px solid #FCAF1A', borderRadius: 10, padding: '10px 14px', marginBottom: 12 }}>
              <span style={{ fontSize: 18, flexShrink: 0 }}>🌙</span>
              <div>
                <div style={{ fontSize: 12, fontWeight: 700, color: '#92610A' }}>
                  {locale === 'it' ? 'Soggiorno minimo consigliato: 3 notti' : locale === 'de' ? 'Empfohlener Mindestaufenthalt: 3 Nächte' : locale === 'pl' ? 'Zalecany minimalny pobyt: 3 noce' : 'Recommended minimum stay: 3 nights'}
                </div>
                <div style={{ fontSize: 11, color: '#B07820', marginTop: 2 }}>
                  {locale === 'it' ? 'Puoi selezionare qualsiasi durata, ma potremmo avere poca disponibilità' : locale === 'de' ? 'Kürzere Aufenthalte sind möglich, aber selten verfügbar' : locale === 'pl' ? 'Krótsze pobyty są możliwe, ale rzadko dostępne' : 'Shorter stays are possible but rarely available'}
                </div>
              </div>
            </div>
          )}
        </div>

        {isDesk ? (
          // Desktop: barra ‹ mese1 | mese2 › + 2 mesi — showTitle=false perché il mese è già nella barra
          <div style={{ padding: '0 24px 20px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
              <button onClick={() => { if (!isPrevDis) { const p = addM(vy, vm, -1); setVY(p.y); setVM(p.m); }}} disabled={isPrevDis}
                style={{ background: 'none', border: 'none', fontSize: 22, cursor: isPrevDis ? 'default' : 'pointer', color: isPrevDis ? '#ddd' : '#333', padding: '0 8px' }}>‹</button>
              <div style={{ display: 'flex', flex: 1, justifyContent: 'space-around' }}>
                <span style={{ fontWeight: 700, fontSize: 15 }}>{mons[vm]} {vy}</span>
                <span style={{ fontWeight: 700, fontSize: 15 }}>{mons[sec.m]} {sec.y}</span>
              </div>
              <button onClick={() => { const n = addM(vy, vm, 1); setVY(n.y); setVM(n.m); }}
                style={{ background: 'none', border: 'none', fontSize: 22, cursor: 'pointer', color: '#333', padding: '0 8px' }}>›</button>
            </div>
            <div style={{ display: 'flex', gap: 24 }}>
              {/* showTitle=false: il titolo è già nella barra ‹ › */}
              {renderMonth(vy, vm, false)}
              <div style={{ width: 1, background: '#f0f0f0', flexShrink: 0 }} />
              {renderMonth(sec.y, sec.m, false)}
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 14 }}>
              <button onClick={() => { setCheckIn(''); setCheckOut(''); setSelectingCheckout(false); }}
                style={{ background: 'none', border: 'none', color: '#888', fontSize: 12, cursor: 'pointer', textDecoration: 'underline', padding: 0 }}>{ui.cancel}</button>
              <button onClick={() => setPanel('none')}
                style={{ padding: '10px 24px', background: '#FCAF1A', color: '#fff', border: 'none', borderRadius: 50, fontWeight: 700, fontSize: 14, cursor: 'pointer' }}>{ui.done}</button>
            </div>
          </div>
        ) : (
          // Mobile: scroll verticale 12 mesi — showTitle=true (unico titolo visibile)
          <>
            <div style={{ padding: '0 20px', overflowY: 'auto', paddingBottom: 80 }}>
              {mobileMonths.map(({ y, m }, idx) => (
                <div key={idx} style={{ marginBottom: 28 }}>
                  <div style={{ fontWeight: 700, fontSize: 15, textAlign: 'center', marginBottom: 10, color: '#111' }}>{mons[m]} {y}</div>
                  {renderMonth(y, m, false)}
                </div>
              ))}
            </div>
            <div style={{ position: 'sticky', bottom: 0, background: '#fff', padding: '10px 20px 24px', borderTop: '1px solid #f0f0f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', zIndex: 10 }}>
              <button onClick={() => { setCheckIn(''); setCheckOut(''); setSelectingCheckout(false); }}
                style={{ background: 'none', border: 'none', color: '#888', fontSize: 12, cursor: 'pointer', textDecoration: 'underline', padding: 0 }}>{ui.cancel}</button>
              <button onClick={() => setPanel('none')}
                style={{ padding: '10px 28px', background: '#FCAF1A', color: '#fff', border: 'none', borderRadius: 50, fontWeight: 700, fontSize: 14, cursor: 'pointer' }}>{ui.done}</button>
            </div>
          </>
        )}
      </div>
    );
  }

  // ── Panel ospiti ──────────────────────────────────────────────────────────
  function GuestsContent() {
    const ageLabel = locale === 'it' ? 'Età bambino' : locale === 'de' ? 'Alter Kind' : locale === 'pl' ? 'Wiek dziecka' : 'Child age';
    const agePlaceholder = locale === 'it' ? 'Seleziona età' : locale === 'de' ? 'Alter wählen' : locale === 'pl' ? 'Wybierz wiek' : 'Select age';
    const yearStr = locale === 'it' ? 'anni' : locale === 'de' ? 'Jahre' : locale === 'pl' ? 'lat' : 'years';
    return (
      <div style={{ padding: 20 }}>
        {!isDesk && <div style={{ width: 40, height: 4, borderRadius: 2, background: '#ddd', margin: '0 auto 16px' }} />}
        {[
          { label: ui.adults, sub: ui.adultsAge, val: numAdult, set: setNumAdult, min: 1 },
          { label: ui.children, sub: ui.childrenAge, val: numChild, set: setNumChild, min: 0 },
        ].map(({ label, sub, val, set, min }) => (
          <div key={label} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 0', borderBottom: '1px solid #f0f0f0' }}>
            <div>
              <div style={{ fontSize: 15, fontWeight: 500 }}>{label}</div>
              <div style={{ fontSize: 12, color: '#999' }}>{sub}</div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
              <button onClick={() => set(val - 1)} disabled={val <= min}
                style={{ width: 34, height: 34, borderRadius: '50%', border: `1.5px solid ${val <= min ? '#e5e7eb' : '#1E73BE'}`, background: '#fff', color: val <= min ? '#ccc' : '#1E73BE', fontSize: 18, cursor: val <= min ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>−</button>
              <span style={{ fontSize: 16, fontWeight: 700, minWidth: 24, textAlign: 'center' }}>{val}</span>
              <button onClick={() => set(val + 1)}
                style={{ width: 34, height: 34, borderRadius: '50%', border: '1.5px solid #1E73BE', background: '#fff', color: '#1E73BE', fontSize: 18, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>+</button>
            </div>
          </div>
        ))}
        {numChild > 0 && (
          <div style={{ marginTop: 14, padding: 14, background: '#f9fafb', borderRadius: 12, border: '1px solid #e5e7eb' }}>
            <div style={{ display: 'grid', gridTemplateColumns: numChild === 1 ? '1fr' : '1fr 1fr', gap: 10 }}>
              {Array.from({ length: numChild }, (_, i) => (
                <div key={i}>
                  <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: '#6b7280', marginBottom: 4, textTransform: 'uppercase' }}>{ageLabel} {i + 1}</label>
                  <select value={childrenAges[i] ?? -1} onChange={e => setChildAge(i, Number(e.target.value))}
                    style={{ width: '100%', padding: '8px 10px', fontSize: 14, borderRadius: 8, border: `1.5px solid ${(childrenAges[i] ?? -1) < 0 ? '#f97316' : '#e5e7eb'}`, background: '#fff', appearance: 'auto' }}>
                    <option value={-1}>{agePlaceholder}</option>
                    {Array.from({ length: 18 }, (_, age) => (
                      <option key={age} value={age}>{age} {yearStr}</option>
                    ))}
                  </select>
                </div>
              ))}
            </div>
          </div>
        )}
        <button onClick={() => setPanel('none')}
          style={{ width: '100%', marginTop: 20, padding: '12px', background: '#FCAF1A', color: '#fff', border: 'none', borderRadius: 50, fontWeight: 700, fontSize: 15, cursor: 'pointer' }}>
          {ui.done}
        </button>
      </div>
    );
  }

  // ── Freccia slider ────────────────────────────────────────────────────────
  function ArrowBtn({ dir, visible, onClick }: { dir: 'left' | 'right'; visible: boolean; onClick: () => void }) {
    // Le frecce stanno dentro il padding laterale (64px desktop)
    // left/right = pad/2 - 18 (metà freccia) → centrata nel padding
    const offset = PAD_DESKTOP / 2 - 18;
    return (
      <button onClick={onClick} style={{
        position: 'absolute',
        [dir === 'left' ? 'left' : 'right']: offset,
        top: '45%', transform: 'translateY(-50%)',
        zIndex: 10, width: 36, height: 36, borderRadius: '50%',
        border: '1px solid #ddd', background: '#fff',
        boxShadow: '0 2px 10px rgba(0,0,0,0.15)',
        cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 18, color: '#333',
        opacity: visible ? 1 : 0,
        transition: 'opacity 0.2s',
        pointerEvents: visible ? 'auto' : 'none',
      }}>{dir === 'left' ? '‹' : '›'}</button>
    );
  }

  // ── Render ────────────────────────────────────────────────────────────────
  const allRooms = PROPERTIES.flatMap(p => p.rooms);
  // Tutte le rooms scrollabili — 7 visibili alla volta grazie alla larghezza fissa card
  const visibleRooms = allRooms;
  const pad = isDesk ? PAD_DESKTOP : PAD_MOBILE;

  return (
    <div style={{ background: '#fff', minHeight: '100vh', boxSizing: 'border-box', width: '100%', overflowX: 'hidden' }}>
      {/* Wrapper centrato 1400px */}
      <div style={{ maxWidth: 1400, margin: '0 auto', width: '100%' }}>

        {/* ══ SEARCH BAR ════════════════════════════════════════════════════ */}
        {isDesk ? (
          // DESKTOP — 3 box stile Airbnb, centrati
          <div style={{ display: 'flex', justifyContent: 'center', padding: `1.5rem ${PAD_DESKTOP}px 1rem`, position: 'relative', zIndex: 100 }}>
            <div style={{
              display: 'flex', alignItems: 'stretch',
              border: '1px solid #dddddd', borderRadius: 32,
              background: '#fff',
              boxShadow: '0 1px 2px rgba(0,0,0,0.08), 0 4px 12px rgba(0,0,0,0.05)',
              maxWidth: 720, width: '100%',
            }}>
              {/* Date */}
              <button onClick={() => setPanel(p => p === 'dates' ? 'none' : 'dates')}
                style={{
                  flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center',
                  padding: '14px 24px', background: panel === 'dates' ? '#f7f7f7' : 'transparent',
                  border: 'none', borderRight: '1px solid #dddddd', cursor: 'pointer', textAlign: 'left',
                  borderRadius: panel === 'dates' ? '32px 0 0 32px' : 0,
                  outline: panel === 'dates' ? '2px solid #222' : 'none', outlineOffset: '-2px',
                  transition: 'background 0.15s',
                }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: '#111', marginBottom: 2 }}>{ui.dates}</div>
                <div style={{ fontSize: 14, color: datesLabel ? '#111' : '#717171', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {datesLabel ?? `${ui.checkin} – ${ui.checkout}`}
                </div>
              </button>
              {/* Persone */}
              <button onClick={() => setPanel(p => p === 'guests' ? 'none' : 'guests')}
                style={{
                  flex: '0 0 210px', display: 'flex', flexDirection: 'column', justifyContent: 'center',
                  padding: '14px 24px', background: panel === 'guests' ? '#f7f7f7' : 'transparent',
                  border: 'none', borderRight: '1px solid #dddddd', cursor: 'pointer', textAlign: 'left',
                  outline: panel === 'guests' ? '2px solid #222' : 'none', outlineOffset: '-2px',
                  transition: 'background 0.15s',
                }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: '#111', marginBottom: 2 }}>{ui.guests}</div>
                <div style={{ fontSize: 14, color: '#111' }}>
                  {guestsLabel ?? `${numAdult} ${locale === 'it' ? 'adulti' : locale === 'de' ? 'Erw.' : 'adults'}`}
                </div>
              </button>
              {/* Lente blu */}
              <div style={{ display: 'flex', alignItems: 'center', padding: '8px 10px 8px 0' }}>
                <button onClick={handleCerca}
                  style={{ width: 48, height: 48, borderRadius: '50%', background: '#1E73BE', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 2px 8px rgba(30,115,190,0.35)', transition: 'background 0.15s, transform 0.1s' }}
                  onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background='#1660a0'; (e.currentTarget as HTMLElement).style.transform='scale(1.06)'; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background='#1E73BE'; (e.currentTarget as HTMLElement).style.transform='scale(1)'; }}>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5">
                    <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
                  </svg>
                </button>
              </div>
            </div>

            {/* Dropdown calendario desktop */}
            {panel === 'dates' && (
              <div style={{ position: 'absolute', top: 'calc(100% - 8px)', left: '50%', transform: 'translateX(-50%)', width: 620, background: '#fff', borderRadius: 16, boxShadow: '0 8px 32px rgba(0,0,0,0.15)', zIndex: 200, overflow: 'hidden' }}>
                <CalContent />
              </div>
            )}
            {/* Dropdown ospiti desktop */}
            {panel === 'guests' && (
              <div style={{ position: 'absolute', top: 'calc(100% - 8px)', left: '50%', transform: 'translateX(-50%)', width: 340, background: '#fff', borderRadius: 16, boxShadow: '0 8px 32px rgba(0,0,0,0.15)', zIndex: 200, overflow: 'hidden' }}>
                <GuestsContent />
              </div>
            )}
            {/* Overlay chiudi dropdown */}
            {panel !== 'none' && (
              <div onClick={() => setPanel('none')} style={{ position: 'fixed', inset: 0, zIndex: 99 }} />
            )}
          </div>
        ) : (
          // MOBILE — 2 box + bottone arancione
          <div style={{ padding: `1.5rem ${PAD_MOBILE}px 0` }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <button onClick={() => setPanel(p => p === 'dates' ? 'none' : 'dates')}
                style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '14px 16px', border: `1.5px solid ${panel === 'dates' ? '#1E73BE' : '#e5e7eb'}`, borderRadius: 14, background: panel === 'dates' ? '#f0f7ff' : '#fff', cursor: 'pointer', textAlign: 'left', width: '100%', boxSizing: 'border-box' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1E73BE" strokeWidth="1.8" style={{ flexShrink: 0 }}>
                  <rect x="3" y="4" width="18" height="18" rx="3"/><path d="M16 2v4M8 2v4M3 10h18"/>
                </svg>
                <div style={{ minWidth: 0, flex: 1 }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: '#888', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{ui.dates}</div>
                  <div style={{ fontSize: 14, fontWeight: 600, color: datesLabel ? '#111' : '#aaa', marginTop: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {datesLabel ?? `${ui.checkin} – ${ui.checkout}`}
                  </div>
                </div>
              </button>
              <button onClick={() => setPanel(p => p === 'guests' ? 'none' : 'guests')}
                style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '14px 16px', border: `1.5px solid ${panel === 'guests' ? '#1E73BE' : '#e5e7eb'}`, borderRadius: 14, background: panel === 'guests' ? '#f0f7ff' : '#fff', cursor: 'pointer', textAlign: 'left', width: '100%', boxSizing: 'border-box' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1E73BE" strokeWidth="1.8" style={{ flexShrink: 0 }}>
                  <circle cx="12" cy="7" r="4"/><path d="M5.5 21c0-3.59 2.91-6.5 6.5-6.5s6.5 2.91 6.5 6.5" strokeLinecap="round"/>
                </svg>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: '#888', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{ui.guests}</div>
                  <div style={{ fontSize: 14, fontWeight: 600, color: '#111', marginTop: 1 }}>
                    {guestsLabel ?? `${numAdult} ${locale === 'it' ? 'adulti' : 'adults'}`}
                  </div>
                </div>
              </button>
              <button onClick={handleCerca}
                style={{ width: '100%', boxSizing: 'border-box', padding: '15px', borderRadius: 50, background: '#FCAF1A', color: '#fff', border: 'none', fontWeight: 700, fontSize: 16, cursor: 'pointer' }}>
                {ui.search}
              </button>
            </div>
          </div>
        )}

        {/* Bottom sheets mobile */}
        {!isDesk && panel !== 'none' && (
          <>
            <div onClick={() => setPanel('none')} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', zIndex: 200 }} />
            <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, zIndex: 201, background: '#fff', borderRadius: '20px 20px 0 0', boxShadow: '0 -4px 24px rgba(0,0,0,0.15)', maxHeight: '88vh', overflowY: 'auto' }}>
              {panel === 'dates'  && <CalContent />}
              {panel === 'guests' && <GuestsContent />}
            </div>
          </>
        )}

        {/* ══ SLIDER RESIDENZE ══════════════════════════════════════════════ */}
        <div style={{ marginTop: isDesk ? '0' : '1.5rem', paddingBottom: 8 }}>
          <h2 style={{ fontSize: isDesk ? '1.4rem' : '1.15rem', fontWeight: 700, margin: '0 0 0.75rem 0', paddingLeft: pad, color: '#111' }}>
            {ui.sliderTitle}
          </h2>
          <div style={{ position: 'relative' }}
            onMouseEnter={() => isDesk && setShowResArr(true)}
            onMouseLeave={() => isDesk && setShowResArr(false)}>
            {isDesk && <ArrowBtn dir="left"  visible={showResArr} onClick={() => scrollSlider(residenzeRef, 'left')} />}
            <div ref={residenzeRef} style={{ display: 'flex', gap: 14, overflowX: 'auto', padding: `4px ${pad}px 16px`, scrollSnapType: 'x mandatory', WebkitOverflowScrolling: 'touch', msOverflowStyle: 'none', scrollbarWidth: 'none' }}>
              {visibleRooms.map(room => {
                const src = covers[room.cloudinaryFolder];
                const cardW = isDesk ? 180 : 120;
                return (
                  <button key={room.roomId} onClick={() => router.push(`/${locale}/residenze/${room.slug}`)}
                    style={{ flexShrink: 0, width: cardW, scrollSnapAlign: 'start', border: 'none', padding: 0, background: 'transparent', cursor: 'pointer', textAlign: 'left' }}>
                    {/* Foto QUADRATA 1:1 */}
                    <div style={{ width: '100%', aspectRatio: '1/1', borderRadius: 14, overflow: 'hidden', background: '#e5e7eb', transition: 'transform 0.15s, box-shadow 0.15s', boxShadow: '0 2px 8px rgba(0,0,0,0.08)' }}
                      onMouseEnter={e => { const el = e.currentTarget as HTMLElement; el.style.transform='scale(1.02)'; el.style.boxShadow='0 6px 18px rgba(0,0,0,0.18)'; }}
                      onMouseLeave={e => { const el = e.currentTarget as HTMLElement; el.style.transform='scale(1)'; el.style.boxShadow='0 2px 8px rgba(0,0,0,0.08)'; }}>
                      {src
                        ? <img src={src} alt={room.name} loading="lazy" style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }} />
                        : <div style={{ width: '100%', height: '100%', background: '#e5e7eb' }} />
                      }
                    </div>
                    {/* Nome sotto — stile Airbnb */}
                    <div style={{ marginTop: 8, paddingLeft: 2 }}>
                      <div style={{ fontSize: isDesk ? 14 : 12, fontWeight: 600, color: '#111', lineHeight: 1.3 }}>{room.name}</div>
                    </div>
                  </button>
                );
              })}
            </div>
            {isDesk && <ArrowBtn dir="right" visible={showResArr} onClick={() => scrollSlider(residenzeRef, 'right')} />}
          </div>
        </div>

        {/* ══ SLIDER DINTORNI ═══════════════════════════════════════════════ */}
        {dintorniPhotos.length > 0 && (
          <div style={{ marginTop: isDesk ? '1.5rem' : '1rem', paddingBottom: 32 }}>
            <h2 style={{ fontSize: isDesk ? '1.4rem' : '1.15rem', fontWeight: 700, margin: '0 0 0.75rem 0', paddingLeft: pad, color: '#111' }}>
              {ui.dintorniTitle}
            </h2>
            <div style={{ position: 'relative' }}
              onMouseEnter={() => isDesk && setShowDintArr(true)}
              onMouseLeave={() => isDesk && setShowDintArr(false)}>
              {isDesk && <ArrowBtn dir="left"  visible={showDintArr} onClick={() => scrollSlider(dintorniRef, 'left')} />}
              <div ref={dintorniRef} style={{ display: 'flex', gap: 14, overflowX: 'auto', padding: `4px ${pad}px 16px`, scrollSnapType: 'x mandatory', WebkitOverflowScrolling: 'touch', msOverflowStyle: 'none', scrollbarWidth: 'none' }}>
                {dintorniPhotos.map((src, idx) => (
                  <button key={idx} onClick={() => setLightbox(src)}
                    style={{ flexShrink: 0, width: isDesk ? 180 : 160, aspectRatio: '1/1', scrollSnapAlign: 'start', border: 'none', padding: 0, background: 'transparent', cursor: 'pointer', borderRadius: 14, overflow: 'hidden', boxShadow: '0 2px 8px rgba(0,0,0,0.08)', transition: 'transform 0.15s, box-shadow 0.15s' }}
                    onMouseEnter={e => { const el = e.currentTarget as HTMLElement; el.style.transform='scale(1.02)'; el.style.boxShadow='0 6px 18px rgba(0,0,0,0.18)'; }}
                    onMouseLeave={e => { const el = e.currentTarget as HTMLElement; el.style.transform='scale(1)'; el.style.boxShadow='0 2px 8px rgba(0,0,0,0.08)'; }}>
                    <img src={src} alt="" loading="lazy" style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }} />
                  </button>
                ))}
              </div>
              {isDesk && <ArrowBtn dir="right" visible={showDintArr} onClick={() => scrollSlider(dintorniRef, 'right')} />}
            </div>
          </div>
        )}

      </div>{/* fine wrapper 1400px */}

      {/* ══ LIGHTBOX (fuori dal wrapper — occupa tutto lo schermo) ══════════ */}
      {lightboxSrc && (
        <div onClick={() => setLightbox(null)}
          style={{ position: 'fixed', inset: 0, zIndex: 1000, background: 'rgba(0,0,0,0.88)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'zoom-out', padding: 24 }}>
          <button onClick={() => setLightbox(null)}
            style={{ position: 'absolute', top: 20, right: 20, width: 40, height: 40, borderRadius: '50%', background: 'rgba(255,255,255,0.15)', border: '1px solid rgba(255,255,255,0.3)', color: '#fff', fontSize: 20, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>✕</button>
          <img src={lightboxSrc} alt="" onClick={e => e.stopPropagation()}
            style={{ maxWidth: '90vw', maxHeight: '85vh', borderRadius: 12, objectFit: 'contain', boxShadow: '0 8px 40px rgba(0,0,0,0.6)', cursor: 'default' }} />
        </div>
      )}

      <style>{`div::-webkit-scrollbar { display: none; }`}</style>
    </div>
  );
}
